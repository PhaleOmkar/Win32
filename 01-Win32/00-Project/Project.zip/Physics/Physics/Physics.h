extern "C" double CalculateCentrifugalForce(double, double, double);
extern "C" double CalculateCentripetalAcceleration(double, double);
